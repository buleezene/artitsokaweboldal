class Vendeg:
    def __init__(self, nev, erkezes):
        self.nev = nev
        self.erkezes = erkezes

